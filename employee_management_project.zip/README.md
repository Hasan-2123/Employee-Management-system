# Employee Management Fullstack Boilerplate

See backend and frontend readmes.
