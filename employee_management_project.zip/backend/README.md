# Backend

Start with `npm install` then `npm run dev`.
