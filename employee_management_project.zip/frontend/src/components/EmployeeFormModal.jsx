import React, { useEffect, useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { useEmployees } from '../context/EmployeeContext';

export default function EmployeeFormModal({ isOpen, onClose, initial }){
  const { addEmployee, updateEmployee } = useEmployees();
  const [form, setForm] = useState({
    name:'', email:'', age:'', dateOfBirth:null, address:'', photo:null
  });

  useEffect(() => {
    if (initial) {
      setForm({
        name: initial.name || '',
        email: initial.email || '',
        age: initial.age || '',
        dateOfBirth: initial.dateOfBirth ? new Date(initial.dateOfBirth) : null,
        address: initial.address || '',
        photo: null
      });
    } else {
      setForm({ name:'', email:'', age:'', dateOfBirth:null, address:'', photo:null });
    }
  }, [initial]);

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    const fd = new FormData();
    fd.append('name', form.name);
    if (form.age) fd.append('age', form.age);
    fd.append('email', form.email);
    if (form.dateOfBirth) fd.append('dateOfBirth', form.dateOfBirth.toISOString());
    if (form.address) fd.append('address', form.address);
    if (form.photo) fd.append('photo', form.photo);

    try {
      if (initial) {
        await updateEmployee(initial._id, fd);
      } else {
        await addEmployee(fd);
      }
      onClose();
    } catch (err) {
      console.error(err);
      alert('Error saving');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-card">
        <h2 className="modal-title">{initial ? 'Edit Employee' : 'Add Employee'}</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Name*</label>
            <input className="form-input" value={form.name} onChange={e => setForm({...form, name: e.target.value})} required />
          </div>

          <div className="form-group">
            <label>Email*</label>
            <input type="email" className="form-input" value={form.email} onChange={e => setForm({...form, email: e.target.value})} required />
          </div>

          <div className="form-group">
            <label>Age</label>
            <input type="number" className="form-input" value={form.age} onChange={e => setForm({...form, age: e.target.value})} />
          </div>

          <div className="form-group">
            <label>Date of Birth</label>
            <DatePicker
              selected={form.dateOfBirth}
              onChange={date => setForm({...form, dateOfBirth: date})}
              dateFormat="dd MMM yyyy"
              placeholderText="Select Date of Birth"
              showYearDropdown
              showMonthDropdown
              dropdownMode="select"
              scrollableYearDropdown
              yearDropdownItemNumber={120}
              maxDate={new Date()}
              className="form-input"
            />
          </div>

          <div className="form-group">
            <label>Address</label>
            <textarea className="form-textarea" value={form.address} onChange={e => setForm({...form, address: e.target.value})} />
          </div>

          <div className="form-group">
            <label>Photo</label>
            <input type="file" onChange={e => setForm({...form, photo: e.target.files ? e.target.files[0] : null})} />
          </div>

          <div className="modal-btn-container">
            <button type="submit" className="save-btn">{initial ? 'Update' : 'Add'}</button>
            <button type="button" className="cancel-btn" onClick={onClose}>Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
