import React from 'react';
import { useEmployees } from '../context/EmployeeContext';

export default function EmployeeList({ onEdit }){
  const { employees, loading, deleteEmployee } = useEmployees();

  return (
    <div className="table-container">
      <table className="employee-table">
        <thead>
          <tr>
            <th>Name</th><th>Email</th><th>Age</th><th>DOB</th><th>Address</th><th>Photo</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {loading ? <tr><td colSpan="7">Loading...</td></tr> :
            employees.length === 0 ? <tr><td colSpan="7">No employees</td></tr> :
            employees.map(emp => (
              <tr key={emp._id}>
                <td>{emp.name}</td>
                <td>{emp.email}</td>
                <td>{emp.age || '-'}</td>
                <td>{emp.dateOfBirth ? new Date(emp.dateOfBirth).toDateString() : '-'}</td>
                <td>{emp.address}</td>
                <td>{emp.photoUrl ? <img src={`http://localhost:5000${emp.photoUrl}`} alt="p" width="50"/> : 'No Photo'}</td>
                <td>
                  <button className="action-btn edit-btn" onClick={() => onEdit(emp)}>Edit</button>
                  <button className="action-btn delete-btn" onClick={() => deleteEmployee(emp._id)}>Delete</button>
                </td>
              </tr>
            ))
          }
        </tbody>
      </table>
    </div>
  );
}
