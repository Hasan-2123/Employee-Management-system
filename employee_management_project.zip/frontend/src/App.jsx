import React, { useState } from 'react';
import { EmployeeProvider } from './context/EmployeeContext';
import EmployeeList from './components/EmployeeList';
import EmployeeFormModal from './components/EmployeeFormModal';

function App(){
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  const handleEdit = (emp) => {
    setEditing(emp);
    setModalOpen(true);
  };

  return (
    <EmployeeProvider>
      <div className="main-container">
        <h1 className="page-title">Employee Management</h1>

        <div className="add-btn-container">
          <button className="add-btn" onClick={() => handleEdit(null)}>+ Add Employee</button>
        </div>

        <EmployeeList onEdit={handleEdit} />

        {modalOpen && (
          <EmployeeFormModal
            isOpen={modalOpen}
            onClose={() => setModalOpen(false)}
            initial={editing}
          />
        )}
      </div>
    </EmployeeProvider>
  );
}

export default App;
